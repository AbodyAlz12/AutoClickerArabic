plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}
android {
    namespace = "com.example.autoclickerar"
    compileSdk = 35
    defaultConfig {
        applicationId = "com.example.autoclickerar"
        minSdk = 24
        targetSdk = 28
        versionCode = 2
        versionName = "1.1"
    }
}
