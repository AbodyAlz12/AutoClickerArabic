package com.example.autoclickerar

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.view.View
import android.widget.*
import android.text.InputType

class MainActivity : Activity() {
    private val prefs by lazy { getSharedPreferences("clicker", MODE_PRIVATE) }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(22, 22, 22, 22)
            layoutDirection = View.LAYOUT_DIRECTION_RTL
        }
        val scroll = ScrollView(this)
        val content = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        scroll.addView(content)
        content.addView(label("النقر التلقائي"))
        content.addView(label("فاصل عشوائي افتراضي: من 20 إلى 40 مللي ثانية. حدّد مربعاً بالسحب فوق التطبيق الذي تريد النقر فيه."))

        val min = field("أقل فاصل (مللي ثانية)", prefs.getInt("minInterval", 20).toString())
        val max = field("أعلى فاصل (مللي ثانية)", prefs.getInt("maxInterval", 40).toString())
        content.addView(min); content.addView(max)

        val maxClicks = field("أقصى عدد نقرات (0 = بلا حد)", prefs.getInt("maxClicks", 0).toString())
        val duration = field("الإيقاف بعد ثوانٍ (0 = بدون مؤقت)", prefs.getInt("duration", 0).toString())
        content.addView(maxClicks); content.addView(duration)

        content.addView(button("حفظ الإعدادات") {
            val lo = (min.text.toString().toIntOrNull() ?: 20).coerceAtLeast(5)
            val hi = (max.text.toString().toIntOrNull() ?: 40).coerceAtLeast(lo)
            prefs.edit().putInt("minInterval", lo).putInt("maxInterval", hi)
                .putInt("maxClicks", (maxClicks.text.toString().toIntOrNull() ?: 0).coerceAtLeast(0))
                .putInt("duration", (duration.text.toString().toIntOrNull() ?: 0).coerceAtLeast(0)).apply()
            Toast.makeText(this, "تم الحفظ: فاصل عشوائي من $lo إلى $hi مللي ثانية", Toast.LENGTH_LONG).show()
        })
        content.addView(button("تفعيل إمكانية الوصول") {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        })
        content.addView(button("السماح بالظهور فوق التطبيقات") {
            if (!Settings.canDrawOverlays(this))
                startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
            else Toast.makeText(this, "الإذن مفعّل", Toast.LENGTH_SHORT).show()
        })
        content.addView(button("إظهار / إخفاء الزر العائم") {
            startService(Intent(this, AutoClickService::class.java).setAction(AutoClickService.ACTION_TOGGLE))
        })
        content.addView(label("الخطوات: فعّل خدمة النقر التلقائي من إعدادات إمكانية الوصول، واسمح بالظهور فوق التطبيقات، ثم أظهر الزر العائم. من الزر اختر «تحديد مربع»، واسحب على الشاشة لتحديد منطقة النقر."))
        root.addView(scroll)
        setContentView(root)
    }

    private fun label(s: String) = TextView(this).apply { text = s; textSize = 16f; setPadding(0, 10, 0, 8) }
    private fun field(h: String, v: String) = EditText(this).apply {
        hint = h; setText(v); textSize = 15f; inputType = InputType.TYPE_CLASS_NUMBER; setSingleLine(true)
    }
    private fun button(s: String, f: () -> Unit) = Button(this).apply { text = s; setOnClickListener { f() } }
}
