package com.example.autoclickerar

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.content.Intent
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Path
import android.graphics.PixelFormat
import android.graphics.RectF
import android.os.Handler
import android.os.Looper
import android.view.*
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import kotlin.math.max
import kotlin.math.min
import kotlin.random.Random

class AutoClickService : AccessibilityService() {
    companion object { const val ACTION_TOGGLE = "com.example.autoclickerar.TOGGLE" }
    private val handler = Handler(Looper.getMainLooper())
    private lateinit var wm: WindowManager
    private var panel: View? = null
    private var selectionOverlay: SelectionView? = null
    private var selecting = false
    private var running = false
    private var clicks = 0
    private var startedAt = 0L
    private var box = RectF(80f, 250f, 500f, 700f)
    private var counter: TextView? = null
    private var toggleButton: Button? = null
    private val prefs by lazy { getSharedPreferences("clicker", MODE_PRIVATE) }

    override fun onServiceConnected() {
        super.onServiceConnected()
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        showPanel()
    }
    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_TOGGLE) {
            if (panel == null) showPanel() else removePanel()
        }
        return START_STICKY
    }
    override fun onAccessibilityEvent(event: android.view.accessibility.AccessibilityEvent?) {}
    override fun onInterrupt() { stopClicks() }

    private fun overlayParams(): WindowManager.LayoutParams = WindowManager.LayoutParams(
        WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT,
        WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
        WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
        PixelFormat.TRANSLUCENT
    ).apply { gravity = Gravity.TOP or Gravity.START; x = 24; y = 180 }

    private fun showPanel() {
        if (panel != null) return
        if (!android.provider.Settings.canDrawOverlays(this)) {
            Toast.makeText(this, "اسمح بالظهور فوق التطبيقات أولاً", Toast.LENGTH_LONG).show(); return
        }
        val layout = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(6,6,6,6); setBackgroundColor(0xEEFFFFFF.toInt()) }
        layout.addView(TextView(this).apply { text = "النقر التلقائي"; gravity = Gravity.CENTER })
        counter = TextView(this).apply { text = "النقرات: 0"; gravity = Gravity.CENTER }
        layout.addView(counter)
        toggleButton = Button(this).apply {
            text = "بدء"
            setOnClickListener { if (running) stopClicks() else startClicks() }
        }
        layout.addView(toggleButton)
        layout.addView(Button(this).apply { text = "تحديد مربع"; setOnClickListener { beginSelection() } })
        layout.addView(Button(this).apply {
            text = "الإعدادات"
            setOnClickListener { startActivity(Intent(this@AutoClickService, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }
        })
        val params = overlayParams()
        layout.setOnTouchListener(object : View.OnTouchListener {
            var sx = 0f; var sy = 0f; var ox = 0; var oy = 0
            override fun onTouch(v: View, e: MotionEvent): Boolean {
                if (e.action == MotionEvent.ACTION_DOWN) { sx=e.rawX; sy=e.rawY; ox=params.x; oy=params.y; return false }
                if (e.action == MotionEvent.ACTION_MOVE) {
                    params.x = ox + (e.rawX-sx).toInt(); params.y = oy + (e.rawY-sy).toInt()
                    try { wm.updateViewLayout(layout, params) } catch (_: Exception) {}
                    return true
                }
                return false
            }
        })
        try { wm.addView(layout, params); panel = layout } catch (_: Exception) {}
    }

    private fun beginSelection() {
        stopClicks()
        if (selectionOverlay != null) return
        selecting = true
        val view = SelectionView()
        val p = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.TOP or Gravity.START }
        try { wm.addView(view, p); selectionOverlay = view }
        catch (_: Exception) { Toast.makeText(this, "تعذر فتح طبقة تحديد المنطقة", Toast.LENGTH_SHORT).show() }
        Toast.makeText(this, "اسحب إصبعك لتحديد المربع، ثم ارفع إصبعك", Toast.LENGTH_LONG).show()
    }

    private inner class SelectionView : View(this@AutoClickService) {
        private val fill = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0x333399FF; style = Paint.Style.FILL }
        private val border = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = 0xFF1565C0.toInt(); style = Paint.Style.STROKE; strokeWidth = 4f; pathEffect = android.graphics.DashPathEffect(floatArrayOf(14f, 10f), 0f)
        }
        private val instruction = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xFF111111.toInt(); textSize = 42f }
        private var sx = 0f; private var sy = 0f; private var ex = 0f; private var ey = 0f; private var drawing = false
        override fun onDraw(canvas: Canvas) {
            super.onDraw(canvas)
            canvas.drawColor(0x22000000)
            canvas.drawText("اسحب لتحديد مربع النقر", 40f, 90f, instruction)
            if (drawing || (ex > sx && ey > sy)) {
                val r = RectF(min(sx,ex), min(sy,ey), max(sx,ex), max(sy,ey))
                canvas.drawRect(r, fill); canvas.drawRect(r, border)
            }
        }
        override fun onTouchEvent(e: MotionEvent): Boolean {
            when (e.action) {
                MotionEvent.ACTION_DOWN -> { sx=e.x; sy=e.y; ex=sx; ey=sy; drawing=true; invalidate(); return true }
                MotionEvent.ACTION_MOVE -> { ex=e.x; ey=e.y; invalidate(); return true }
                MotionEvent.ACTION_UP -> {
                    ex=e.x; ey=e.y; drawing=false
                    box = RectF(min(sx,ex), min(sy,ey), max(sx,ex), max(sy,ey))
                    if (box.width() < 12 || box.height() < 12) {
                        Toast.makeText(this@AutoClickService, "المربع صغير جداً، حاول مرة أخرى", Toast.LENGTH_SHORT).show()
                    } else {
                        prefs.edit().putFloat("boxLeft", box.left).putFloat("boxTop", box.top)
                            .putFloat("boxRight", box.right).putFloat("boxBottom", box.bottom).apply()
                        Toast.makeText(this@AutoClickService, "تم حفظ منطقة النقر", Toast.LENGTH_SHORT).show()
                    }
                    removeSelection(); return true
                }
            }
            return true
        }
    }

    private fun removeSelection() {
        selectionOverlay?.let { try { wm.removeView(it) } catch (_: Exception) {} }
        selectionOverlay = null; selecting = false
    }

    private fun startClicks() {
        if (running) return
        box = RectF(
            prefs.getFloat("boxLeft", box.left), prefs.getFloat("boxTop", box.top),
            prefs.getFloat("boxRight", box.right), prefs.getFloat("boxBottom", box.bottom)
        )
        if (box.width() < 12 || box.height() < 12) {
            Toast.makeText(this, "اضغط «تحديد مربع» أولاً", Toast.LENGTH_LONG).show(); return
        }
        running = true; clicks = 0; startedAt = System.currentTimeMillis()
        toggleButton?.text = "إيقاف"
        tick()
    }
    private fun stopClicks() {
        running = false; handler.removeCallbacksAndMessages(null)
        if (toggleButton != null) toggleButton?.text = "بدء"
    }

    private fun tick() {
        if (!running) return
        val maxClicks = prefs.getInt("maxClicks", 0)
        val duration = prefs.getInt("duration", 0)
        if ((maxClicks > 0 && clicks >= maxClicks) ||
            (duration > 0 && System.currentTimeMillis() - startedAt >= duration * 1000L)) {
            stopClicks(); return
        }
        val x = Random.nextDouble(box.left.toDouble(), max(box.left + 1f, box.right).toDouble()).toFloat()
        val y = Random.nextDouble(box.top.toDouble(), max(box.top + 1f, box.bottom).toDouble()).toFloat()
        val path = Path().apply { moveTo(x, y); lineTo(x + 0.1f, y + 0.1f) }
        val gesture = GestureDescription.Builder().addStroke(
            GestureDescription.StrokeDescription(path, 0, 1L)
        ).build()
        dispatchGesture(gesture, object : GestureResultCallback() {
            override fun onCompleted(gestureDescription: GestureDescription?) {
                clicks++; counter?.text = "النقرات: $clicks"
            }
        }, null)
        val lo = prefs.getInt("minInterval", 20).coerceAtLeast(5)
        val hi = prefs.getInt("maxInterval", 40).coerceAtLeast(lo)
        val delay = Random.nextLong(lo.toLong(), hi.toLong() + 1L)
        handler.postDelayed({ tick() }, delay)
    }

    private fun removePanel() {
        stopClicks(); removeSelection()
        panel?.let { try { wm.removeView(it) } catch (_: Exception) {} }; panel = null
    }
    override fun onDestroy() { removePanel(); super.onDestroy() }
}
